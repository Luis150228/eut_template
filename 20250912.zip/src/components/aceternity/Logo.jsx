import { motion } from 'framer-motion';
const Logo = () => {
	return (
		<a
			href='#'
			className='relative z-20 flex items-center space-x-2 py-1 text-sm font-normal text-black'>
			<div className='h-5 w-6 shrink-0 rounded-tl-lg rounded-tr-sm rounded-br-lg rounded-bl-sm bg-black dark:bg-white' />
			<motion.span
				initial={{ opacity: 0 }}
				animate={{ opacity: 1 }}
				className='font-medium whitespace-pre text-black dark:text-white'>
				Acet Labs
			</motion.span>
		</a>
	);
};
export default Logo;
