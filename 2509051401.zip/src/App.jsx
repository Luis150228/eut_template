import './App.css';
import { SidebarDemo } from './components/aceternity/SidebarDemo';

function App() {
	return (
		<>
			<div className='enter'>Ahora sí entra con punch 🚀</div>
			<SidebarDemo />
		</>
	);
}

export default App;
