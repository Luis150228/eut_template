import React, { useEffect, useState } from 'react';
import { BentoGrid, BentoGridItem } from '../ui/bento-grid';
import { cn } from '@/lib/utils';
import {
	IconClipboardCopy,
	IconFileBroken,
	IconSignature,
	IconTableColumn,
	IconArrowWaveRightUp,
	IconBoxAlignTopLeft,
	IconBoxAlignRightFilled,
} from '@tabler/icons-react';
import FlamaSantanderLoader from '../images/FlamaSantanderLoader';
import LoaderBackdrop from '../images/LoaderBackdrop';
import EUTLineChart from '../charts/EUTLineChart';
import TablaDraw from '../tables/tableDrawing';
import FlowbiteForm from '../forms/FlowbiteForm';

const ICON = (Comp) => <Comp className='h-4 w-4 text-[var(--brand-red)]' />;
const Skeleton = () => (
	<div className='h-full w-full min-h-[6rem] rounded-xl bg-gradient-to-br from-neutral-200 to-neutral-100 dark:from-neutral-900 dark:to-neutral-800' />
);

/* 1) Mapa de tamaños → clases Tailwind */
const spanClass = (span) => {
	switch (span) {
		case 'full':
			return 'col-span-full md:col-span-12';
		case 'half':
			return 'md:col-span-6';
		case 'third':
			return 'md:col-span-4';
		case 'quarter':
			return 'md:col-span-3';
		case 'tall':
			return 'row-span-2';
		case 'half-tall':
			return 'md:col-span-6 row-span-2';
		case 'full-tall':
			return 'col-span-full md:col-span-12 row-span-2 h-full';
		default:
			return '';
	}
};

/* 2) Orden cíclico de tamaños */
const SPAN_ORDER = ['quarter', 'third', 'half', 'tall', 'half-tall', 'full', 'full-tall'];
const nextSpan = (cur) => {
	const i = SPAN_ORDER.indexOf(cur);
	return i === -1 ? SPAN_ORDER[0] : SPAN_ORDER[(i + 1) % SPAN_ORDER.length];
};

/* 3) Persistencia en localStorage */
const STORAGE_KEY_SPANS = 'eut.cardSpans.v1';
function loadSpanMap() {
	if (typeof window === 'undefined') return {};
	try {
		const raw = localStorage.getItem(STORAGE_KEY_SPANS);
		return raw ? JSON.parse(raw) : {};
	} catch {
		return {};
	}
}
function saveSpan(id, span) {
	if (typeof window === 'undefined' || !id) return;
	const map = loadSpanMap();
	map[id] = span;
	try {
		localStorage.setItem(STORAGE_KEY_SPANS, JSON.stringify(map));
	} catch {}
}

/* 4) Loader de reemplazo para header */
const HeaderLoader = ({ size = 96 }) => (
	<LoaderBackdrop>
		<FlamaSantanderLoader
			size={110}
			strokeWidth={5}
			duration={2.4}
		/>
	</LoaderBackdrop>
);

export function BentoGridEUT() {
	// ——— Items base (añadí data-id a todos) ———
	const baseItems = [
		{
			title: 'Stock de Almacen',
			description: 'Stock de equipos asignados a mi almacén.',
			header: <Skeleton />,
			icon: ICON(IconClipboardCopy),
			span: 'half-tall',
			'data-id': 'stock-almacen',
		},
		{
			title: 'Grafica de Ejemplo Apache ECharts',
			header: (
				<EUTLineChart
					fill
					title='Stock semanal'
					categories={['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom']}
					series={[
						{ name: 'Entradas', data: [12, 18, 10, 14, 9, 13, 11] },
						{ name: 'Salidas', data: [10, 12, 8, 16, 7, 12, 9] },
					]}
					smooth
					className='h-full p-0 border-0 bg-transparent shadow-none'
				/>
			),
			icon: ICON(IconFileBroken),
			span: 'half-tall',
			'data-id': 'grafica-echarts',
		},
		{
			title: 'Tabla de Ejemplo',
			header: <TablaDraw />, // ya trae su wrapper h-full/min-h-0/overflow-hidden
			icon: ICON(IconSignature),
			span: 'full-tall',
			'data-id': 'tabla-ejemplo',
		},
		{
			title: 'Formulario de Ejemplo',
			header: <FlowbiteForm />,
			icon: ICON(IconSignature),
			span: 'half',
			'data-id': 'formulario-ejemplo',
		},
		{
			title: 'Power of Communication',
			header: <Skeleton />,
			icon: ICON(IconTableColumn),
			span: 'third',
			'data-id': 'power-communication',
		},
		{
			title: 'Pursuit of Knowledge',
			header: <Skeleton />,
			icon: ICON(IconArrowWaveRightUp),
			span: 'third',
			'data-id': 'pursuit-knowledge',
		},
		{
			title: 'Joy of Creation',
			header: <Skeleton />,
			icon: ICON(IconBoxAlignTopLeft),
			span: 'third',
			'data-id': 'joy-creation',
		},
		{
			title: 'Spirit of Adventure',
			header: <Skeleton />,
			icon: ICON(IconBoxAlignRightFilled),
			span: 'third',
			'data-id': 'spirit-adventure',
		},
	];

	// ——— Inicializa items aplicando spans guardados por data-id ———
	const [items, setItems] = useState(() => {
		const saved = loadSpanMap();
		return baseItems.map((it) => {
			const id = it['data-id'];
			const savedSpan = id ? saved[id] : null;
			return savedSpan ? { ...it, span: savedSpan } : it;
		});
	});

	// ——— Loading demo ———
	const [loadingIdx, setLoadingIdx] = useState(new Set());
	const setCardLoading = (idx, on) =>
		setLoadingIdx((prev) => {
			const next = new Set(prev);
			on ? next.add(idx) : next.delete(idx);
			return next;
		});
	const loaderOnElement = async () => {
		const idx = 0;
		setCardLoading(idx, true);
		try {
			await new Promise((r) => setTimeout(r, 1500));
		} finally {
			setCardLoading(idx, false);
		}
	};

	// ——— Botones barra inferior ———
	const handleToggleSize = (idx) => {
		setItems((prev) =>
			prev.map((it, i) => {
				if (i !== idx) return it;
				const id = it['data-id'] || `item-${i}`;
				const newSpan = nextSpan(it.span);
				saveSpan(id, newSpan);
				return { ...it, span: newSpan };
			})
		);
	};
	const handleClose = (idx) => {
		setItems((prev) => prev.filter((_, i) => i !== idx));
		// Nota: no borro el valor guardado; si quieres, aquí podrías limpiarlo:
		// const id = items[idx]?.['data-id']; if (id) { const m = loadSpanMap(); delete m[id]; localStorage.setItem(STORAGE_KEY_SPANS, JSON.stringify(m)); }
	};

	return (
		<>
			<div className='mt-4'>
				<button
					onClick={loaderOnElement}
					className='rounded-md bg-neutral-200 px-3 py-2 dark:bg-neutral-800'>
					Actualizar element
				</button>
			</div>

			<BentoGrid
				className={cn(
					'mx-auto w-full max-w-screen-2xl',
					'grid grid-cols-1 md:grid-cols-12 gap-4 auto-rows-[12rem]',
					'grid-flow-row-dense'
				)}>
				{items.map((item, i) => {
					const { span, className: cls, header, title, description, icon, ...dataRest } = item;
					return (
						<BentoGridItem
							key={i}
							{...dataRest} // ← data-id queda en el DOM
							title={title}
							description={description}
							header={
								<div className='h-full min-h-0 overflow-hidden'>{loadingIdx.has(i) ? <HeaderLoader /> : header}</div>
							}
							icon={icon}
							onToggleSize={() => handleToggleSize(i)}
							onClose={() => handleClose(i)}
							className={cn('min-w-0', spanClass(span), cls)}
						/>
					);
				})}
			</BentoGrid>
		</>
	);
}
