import XlsxExporter from './XlsxExporter';

const sample = {
	task_effective_number: 'INC058334530',
	number: 'INC058334530',
	sys_created_on: '2025-09-09 08:52:56',
	work_end: '',
	closed_at: '',
	closed_by: '',
	assignment_group: 'TMX_EU_CAU_Zona_1_Metro_Edificios',
	assigned_to: '',
	state: 'Nuevo',
	category: 'Dispositivo Usuario Final',
	subcategory: 'Portatil',
	u_short_description_call: '',
	u_request_type: '',
	short_description:
		'Reportes de Fallas en Hardware en equipos de cómputo y perifericos (Desktop, laptop, nettop, mouse, Monitor, etc)',
	made_sla: 'verdadero',
	u_zone: 'Zone 1',
	location: 'EDIF. REFORMA 490 CDMX',
	caller_id: 'JESSICA MARTINEZ GARCIA',
	sys_updated_by: 'C923978@santander.com.mx',
	calendar_duration: '0',
	business_duration: '0',
	company: 'Santander México',
	description:
		'Variables: Correo electrónico: jessicmartinez@openbank.mx Expediente: 612890 Extension de Segundo Contacto: 5580043632 Segundo Contacto: 5580043632 Empresa: Corporativo Teléfono: (01 55) 52578000 Tipo de Falla: Otro Nombre: JESSICA MARTINEZ GARCIA Tipo de equipo: Portátil (Laptop) Módulo/Sector/Piso: Prolongacion Paseo de la Reforma Extensión: 5580043632 Marca: Lenovo Departamento: Open Chief Compliance Officer Celular: 5580043632 Describa de manera clara la Solicitud o Falla que está reportando.: OpenBank, favor de apoyar ya que mi computadora no enciende, favor de asignar a Alfredo Sánchez.',
	comments_and_work_notes: '',
	opened_by: 'JESSICA MARTINEZ GARCIA',
	resolved_by: '',
	close_code: '',
	parent_incident: '',
	child_incidents: '0',
	sys_updated_on: '2025-09-09 08:52:57',
	sys_created_by: 'C923978@santander.com.mx',
	work_start: '2025-09-09 08:52:56',
	opened_at: '2025-09-09 08:52:56',
};

export default function DemoExport() {
	const data = Array.from({ length: 10 }, () => sample); // demo

	// Opcional: definir columnas con anchos/flags específicos
	const columns = [
		{ key: 'number', header: 'Folio', width: 18 },
		{ key: 'state', header: 'Estatus', width: 14 },
		{ key: 'company', header: 'Compañía', width: 22 },
		{ key: 'location', header: 'Ubicación', width: 28 },
		{ key: 'sys_created_on', header: 'Creado', isDate: true, width: 20 },
		{ key: 'closed_at', header: 'Cerrado', isDate: true, width: 20 },
		{ key: 'assigned_to', header: 'Asignado a', width: 24 },
		{ key: 'short_description', header: 'Resumen', width: 30 },
		{ key: 'description', header: 'Descripción', wrap: true, width: 60 },
		{ key: 'comments_and_work_notes', header: 'Notas', wrap: true, width: 60 },
		{ key: 'made_sla', header: 'SLA Cumplido', width: 15 },
	];

	return (
		<div className='flex items-center gap-8'>
			<XlsxExporter
				data={data}
				columns={columns}
				fileName='incidentes_demo.xlsx'
			/>
		</div>
	);
}
