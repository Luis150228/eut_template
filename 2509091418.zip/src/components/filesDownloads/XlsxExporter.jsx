'use client';
import React, { useState } from 'react';
import ExcelJS from 'exceljs';
import { IconDownload } from '@tabler/icons-react';
import { cn } from '@/lib/utils';

/** util — parse 'YYYY-MM-DD HH:mm:ss' a Date local (sin zona). */
function parseMysqlLikeDate(s) {
	if (!s || typeof s !== 'string') return null;
	const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})$/.exec(s);
	if (!m) return null;
	const [, y, mo, d, h, mi, se] = m.map(Number);
	// Date(año, mesIndex, día, hora, min, seg)
	return new Date(y, mo - 1, d, h, mi, se);
}

/** util — calcula anchos aproximados en caracteres a partir del contenido */
function autosizeWidths(rows, colsDef) {
	const maxChars = (text) => String(text ?? '').length;
	const widths = colsDef.map((c) => Math.max(maxChars(c.header), 6));
	for (const r of rows) {
		colsDef.forEach((c, i) => {
			const v = r[c.key];
			const len = Array.isArray(v) || typeof v === 'object' ? JSON.stringify(v).length : maxChars(v);
			widths[i] = Math.min(Math.max(widths[i], len + 2), 60); // cap en 60
		});
	}
	return widths;
}

/**
 * props:
 * - data: array<object>
 * - fileName?: string
 * - columns?: Array<{ key: string; header?: string; width?: number; wrap?: boolean; isDate?: boolean }>
 *   Si no pasas columns, se infiere del primer objeto.
 */
export default function XlsxExporter({ data, fileName = 'incidents.xlsx', columns, className }) {
	const [busy, setBusy] = useState(false);

	const cols = React.useMemo(() => {
		if (columns?.length) return columns;
		const first = data?.[0] ?? {};
		return Object.keys(first).map((k) => ({
			key: k,
			header: k,
			wrap: ['description', 'comments_and_work_notes'].includes(k),
			isDate: ['sys_created_on', 'work_end', 'closed_at', 'work_start', 'opened_at', 'sys_updated_on'].includes(k),
		}));
	}, [columns, data]);

	async function handleDownload() {
		if (!Array.isArray(data) || data.length === 0) return;
		setBusy(true);
		try {
			const wb = new ExcelJS.Workbook();
			wb.created = new Date();
			wb.modified = new Date();

			const ws = wb.addWorksheet('Incidentes', {
				views: [{ state: 'frozen', ySplit: 1 }], // congela encabezado
			});

			// Encabezados
			ws.columns = cols.map((c) => ({
				header: c.header ?? c.key,
				key: c.key,
			}));

			// Estilo de encabezado
			const brand = 'FFC51617'; // ARGB – rojo Santander
			const headerRow = ws.getRow(1);
			headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
			headerRow.alignment = { vertical: 'middle', horizontal: 'center', wrapText: true };
			headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: brand } };
			headerRow.border = {
				bottom: { style: 'thin', color: { argb: brand } },
			};
			headerRow.height = 24;

			// Filas
			data.forEach((item) => {
				// clona y convierte fechas si aplica
				const rowObj = {};
				cols.forEach((c) => {
					let v = item[c.key];
					if (c.isDate && typeof v === 'string') {
						const d = parseMysqlLikeDate(v);
						if (d) v = d; // ExcelJS detecta Date y podemos formatear
					}
					rowObj[c.key] = v;
				});
				ws.addRow(rowObj);
			});

			// Formatos por columna (fechas + wrap de textos largos)
			cols.forEach((c, idx) => {
				const col = ws.getColumn(idx + 1);
				if (c.isDate) {
					col.numFmt = 'yyyy-mm-dd hh:mm:ss';
				}
				if (c.wrap) {
					col.alignment = { ...col.alignment, wrapText: true, vertical: 'top' };
				}
			});

			// Zebra rows + marcar filas según regla (ejemplo: made_sla === 'verdadero')
			const okFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE6F4EA' } }; // verde muy suave
			const zebraFill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8F8F8' } };

			for (let r = 2; r <= ws.rowCount; r++) {
				const row = ws.getRow(r);
				// zebra
				if (r % 2 === 0) {
					row.eachCell((cell) => {
						cell.fill = zebraFill;
					});
				}
				// regla: made_sla
				const madeSla = row.getCell(cols.findIndex((c) => c.key === 'made_sla') + 1)?.value;
				if (String(madeSla).toLowerCase() === 'verdadero') {
					row.eachCell((cell) => {
						cell.fill = okFill;
					});
				}
				row.alignment = { vertical: 'top' };
			}

			// AutoFilter
			ws.autoFilter = {
				from: { row: 1, column: 1 },
				to: { row: 1, column: cols.length },
			};

			// Bordes finos
			ws.eachRow((row, rowNumber) => {
				row.eachCell((cell) => {
					cell.border = cell.border || {};
					cell.border.right = { style: 'hair', color: { argb: 'FFDDDDDD' } };
				});
			});

			// Anchos
			const autoWidths = autosizeWidths(
				data,
				cols.map((c) => ({ key: c.key, header: c.header ?? c.key }))
			);
			cols.forEach((c, i) => {
				ws.getColumn(i + 1).width = c.width ?? autoWidths[i];
			});

			// Generar y descargar
			const buf = await wb.xlsx.writeBuffer();
			const blob = new Blob([buf], {
				type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
			});
			const url = URL.createObjectURL(blob);
			const a = document.createElement('a');
			a.href = url;
			a.download = fileName;
			a.click();
			URL.revokeObjectURL(url);
		} finally {
			setBusy(false);
		}
	}

	return (
		<button
			type='button'
			onClick={handleDownload}
			disabled={busy || !data?.length}
			className={cn(
				'inline-flex items-center gap-2 rounded-md border border-[var(--border)]',
				'bg-[var(--card)] px-3 py-1.5 text-sm shadow-sm hover:bg-black/5 dark:hover:bg-white/10',
				busy && 'opacity-60 pointer-events-none',
				className
			)}
			title='Descargar XLSX'>
			<IconDownload className='h-4 w-4' />
			{busy ? 'Generando…' : 'Descargar XLSX'}
		</button>
	);
}
