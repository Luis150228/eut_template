const LogoIcon = () => {
	return (
		<a
			href='#'
			className='relative z-20 flex items-center space-x-2 py-1 text-sm font-normal text-black'>
			<div className='h-5 w-6 shrink-0 rounded-tl-lg rounded-tr-sm rounded-br-lg rounded-bl-sm bg-black dark:bg-white' />
		</a>
	);
};

export default LogoIcon;
